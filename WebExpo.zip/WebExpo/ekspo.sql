-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Des 2023 pada 09.25
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ekspo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `alam`
--

CREATE TABLE `alam` (
  `id` int(225) NOT NULL,
  `judul` varchar(225) NOT NULL,
  `gambar` varchar(225) NOT NULL,
  `informasi` varchar(225) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `alam`
--

INSERT INTO `alam` (`id`, `judul`, `gambar`, `informasi`, `tanggal`) VALUES
(1, 'Gunung Merapi', 'merapi.jpeg', 'Gunung berapi aktif di Jawa Tengah dan Yogyakarta yang menarik pendaki dan peneliti dengan keindahan alam dan nilai sejarahnya.\r\n\r\n', '2023-11-07'),
(5, 'Hutan Pinus Mangunan', 'Hutan-Pinus-Mangunan-768x504.jpg', 'Pelarian dari kepenatan kota dengan suasana sejuk dan pemandangan alam memukau.\r\n', '2023-11-09'),
(9, 'Air Terjun Sri Gethuk', 'air-terjun-sri-gethuk.jpg', 'Ketenangan dan keindahan alam di air terjun Sri Gethuk dengan gemericik air dan lingkungan asri.\r\n', '2023-11-30'),
(13, 'Parangtritis', 'parangtritis.jpg', 'Keindahan pantai dengan ombak tenang, pasir putih, dan matahari terbenam spektakuler.\r\n\r\n', '2023-11-09'),
(14, 'Air Terjun Telaga Muncar', '1644810079371283-1.jpg', 'Telaga ini dikenal karena kejernihan airnya dan keindahan alam sekitarnya. Di sekitar telaga, terdapat hutan hijau yang menambah pesona tempat ini.', '2023-11-28'),
(16, 'Bukit Klangon', '599-1.jpg', 'Bukit ini menawarkan pemandangan spektakuler yang memukau para pengunjungnya. ', '2023-11-26');

-- --------------------------------------------------------

--
-- Struktur dari tabel `budaya`
--

CREATE TABLE `budaya` (
  `id` int(225) NOT NULL,
  `judul` varchar(225) NOT NULL,
  `gambar` varchar(225) NOT NULL,
  `tanggal` date NOT NULL,
  `informasi` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `budaya`
--

INSERT INTO `budaya` (`id`, `judul`, `gambar`, `tanggal`, `informasi`) VALUES
(6, 'Candi Ijo', 'candi ijo.jpg', '2023-12-02', 'Candi Ijo memukau para pecinta sejarah dengan arsitektur khas Jawa.\r\n'),
(7, 'Keraton Yogyakarta', 'R.jpg', '2023-11-28', 'Kunjungan ke Keraton Yogyakarta membawa kembali ke masa lalu dengan keindahan arsitektur dan kekayaan budaya.\r\n\r\n'),
(8, 'Candi Prambanan', 'prambanan.jpeg', '2023-11-29', 'Masterpiece arsitektur megah dengan relief Ramayana yang menciptakan suasana mistis'),
(9, 'Candi Kalasan', 'candi kalasan.jpg', '2023-11-29', 'Saksi bisu kejayaan Kerajaan Mataram Kuno'),
(10, 'Candi Plaosan', 'candi plaosan.jpg', '2023-11-26', 'Perpaduan arsitektur Buddha dan Hindu'),
(11, 'Candi Sewu', 'candi sewu.jpg', '2023-11-29', 'Komplek candi Buddha terbesar di Indonesia dengan lebih dari 200 candi.'),
(12, 'Candi Kimpulan', 'candi kimpulan.jpg', '2023-11-01', 'Arkeologi yang penting karena merupakan satu-satunya candi Hindu yang ditemukan di Yogyakarta'),
(13, 'Taman Sari', 'taman sari.jpg', '2023-11-16', 'Pengalaman istana zaman dahulu dengan keindahan taman, kolam, dan cerita sejarah.\r\n'),
(14, 'Museum Sonobudoyo', 'sonobudoyo.jpg', '2023-11-22', 'Museum yang wajib dikunjungi oleh pecinta seni dan budaya Jawa.'),
(15, 'Benteng Vredeburg', 'bentengvredeburg.jpg', '2023-12-01', 'Museum yang menyimpan sejarah perjuangan bangsa Indonesia yang membanggakan.'),
(16, 'Museum Affandi', 'affandi.jpg', '2023-11-29', 'Museum yang menyimpan karya-karya seni lukis yang indah dan inspiratif.'),
(17, 'Candi Borobudur', 'boro.jpg', '2023-05-03', 'Masterpiece arsitektur yang megah, dengan struktur bertingkat yang menggambarkan perjalanan spiritual dalam ajaran Buddha.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `even`
--

CREATE TABLE `even` (
  `id` int(225) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `deskripsi` varchar(2250) NOT NULL,
  `gambar` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `even`
--

INSERT INTO `even` (`id`, `nama`, `deskripsi`, `gambar`) VALUES
(4, 'Yogyakarta Gamelan Festival', 'Wadah berkumpulnya para pemain dan pencinta alat musik gamelan. Bukan cuma dari dalam Indonesia, melainkan juga dari luar negeri.\r\n\r\n', 'YGF.jpg'),
(5, 'Festival Kebudayaan Yogyakarta', 'FKY menampilkan pameran seni rupa, kompetisi kesenian, pertunjukan budaya, dan pasar festival.', 'FKY.jpg'),
(6, 'Wayang Jogja Night Carnival', 'Beragam kreasi kesenian dari tokoh wayang kapi-kapi dalam bentuk tarian yang dibalut aneka kostum unik, juga patung karakter wayang kapi-kapi dalam ukuran besar. ', 'WJNC.jpg'),
(7, 'Lanterne Festival de Paris', 'Kegiatan penerbangan lampion tahun kedua yang akan di selenggarakan di Kawasan Wisata pantai Parangtritis.', 'lampion.jpg'),
(8, 'Prambanan Jazz', 'Festival ini umumnya dilakukan selama tiga hari dengan waktu pelaksanaan berbeda-beda setiap tahunnya.', 'prambananjazz.jpg'),
(10, 'Jogja Volkswagen Festival (JVWF)', ' Festival ini bertujuan untuk mempromosikan mobil Volkswagen.', 'maxresdefault.jpg'),
(11, 'Jogja Street Food Festival', 'Festival ini menampilkan berbagai macam kuliner jalanan khas Yogyakarta.', 'capture_01272022_153840.jpg'),
(12, 'Pasar Kangen', 'Event ini menampilkan berbagai macam kuliner tradisional Jawa, seni, dan kerajinan tangan', 'pasar kangen.jpg'),
(14, 'Grebeg Maulud', 'Grebeg Maulud adalah upacara di mana berbagai gunungan makanan dan hasil bumi dibagikan kepada masyarakat', 'R (1).jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hiburan`
--

CREATE TABLE `hiburan` (
  `id` int(225) NOT NULL,
  `judul` varchar(225) NOT NULL,
  `gambar` varchar(225) NOT NULL,
  `tanggal` date NOT NULL,
  `informasi` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `hiburan`
--

INSERT INTO `hiburan` (`id`, `judul`, `gambar`, `tanggal`, `informasi`) VALUES
(6, 'Taman Pelangi', 'Harga-Tiket-Masuk-Taman-Pelangi-Jogja.jpg', '2023-12-01', 'Surga bagi keluarga dengan wahana menyenangkan dan suasana ceria untuk semua usia'),
(7, 'Taman Pintar', 'pintar.jpg', '2023-11-27', ' Tempat bermain dan pembelajaran interaktif yang menyenangkan, terutama untuk anak-anak.\r\n'),
(8, 'Sendra Tari Candi Parmbanan', 'sendra tari candi prambanan.jpg', '2023-08-31', 'Pertunjukan tari epik yang menggambarkan kisah Ramayana, diselenggarakan di dekat Candi Prambanan.\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kuliner`
--

CREATE TABLE `kuliner` (
  `id` int(225) NOT NULL,
  `isi` varchar(225) NOT NULL,
  `gambar` varchar(225) NOT NULL,
  `nama_kuliner` varchar(225) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kuliner`
--

INSERT INTO `kuliner` (`id`, `isi`, `gambar`, `nama_kuliner`, `tanggal`) VALUES
(6, 'Sate yang menggunakan tusuk bambu besar dan daging kambing sebagai bahan utama. Rasanya khas dan menjadi kuliner yang populer di Yogyakarta.\r\n', 'klathak.jpg', 'Sate Klathak', '2023-12-02'),
(7, 'Kue tradisional Yogyakarta yang terkenal. Terbuat dari campuran tepung terigu dan gula, bakpia memiliki berbagai varian rasa seperti kacang hijau, coklat, dan keju.\r\n', 'bakpia.jpg', 'Bakpia', '2023-12-01'),
(8, 'Masakan khas Yogyakarta yang terbuat dari nangka muda yang dimasak dengan santan dan bumbu khas. Biasanya disajikan dengan nasi, telur, ayam, dan sambal.\r\n', 'gudeg.jpg', 'Gudeg', '2023-12-01'),
(9, 'Kuliner khas Yogyakarta yang terbuat dari tulang kambing yang direbus dengan kuah yang gurih dan pedas.', 'tengkleng.jpg', 'Tengkleng', '2023-11-28'),
(10, 'Minuman tradisional yang terbuat dari campuran rempah-rempah seperti serai, jahe, kayu manis, dan bahan alami lainnya', 'shutterstock_1722307129.jpg', 'Wedang Uwuh', '2023-10-17'),
(11, 'Camilan manis khas Yogyakarta yang terbuat dari kulit tepung ketan yang tipis, diisi dengan campuran gula, kacang hijau, atau wijen', 'hay.jpg', 'Kipo', '2023-08-08');

-- --------------------------------------------------------

--
-- Struktur dari tabel `registrasi`
--

CREATE TABLE `registrasi` (
  `id` int(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `registrasi`
--

INSERT INTO `registrasi` (`id`, `email`, `password`, `username`) VALUES
(1, 'admin@hotmail.com', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(2, 'kiting@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759', 'azzik'),
(3, 'h@gmail.com', '2510c39011c5be704182423e3a695e91', 'h'),
(4, 'dede@gmail.com', 'b4be1c568a6dc02dcaf2849852bdb13e', 'dede'),
(5, 'kurobi@gmail.com', 'd7b3bbbc0a472166030089695af7d5cb', 'kurobi'),
(6, 'kka@gmail.com', '491c0f7fc037cde776b5e71a00b8c2f4', 'kka'),
(7, 'z@gmail.com', 'fbade9e36a3f36d3d676c1b808451dd7', 'z'),
(8, 'kocak@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'kocak'),
(9, 'des@gmail.com', '0ecee728bf87a4c1a02883004044dcd5', 'design');

-- --------------------------------------------------------

--
-- Struktur dari tabel `testimoni`
--

CREATE TABLE `testimoni` (
  `foto` varchar(225) NOT NULL,
  `komentar` varchar(225) NOT NULL,
  `tanggal` date NOT NULL,
  `id` int(225) NOT NULL,
  `nama` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `testimoni`
--

INSERT INTO `testimoni` (`foto`, `komentar`, `tanggal`, `id`, `nama`) VALUES
('edsfv.jpeg', 'Beautiful', '2023-12-05', 2, 'Edward'),
('Picture2.jpg', 'Air terjun Sri Gethuk menawarkan ketenangan dan keindahan alam yang mempesona', '2023-12-01', 3, 'Askuri'),
('Picture6.jpg', 'Jogja sangat indah', '2023-12-04', 4, 'Kaka'),
('qs.jpeg', 'Amazing', '2023-12-10', 5, 'Dul'),
('Picture3.jpg', 'haloo', '2023-11-30', 6, 'jesna'),
('Picture4.jpg', 'wow bagus sekali', '2023-12-04', 7, 'safinatun'),
('l.jpg', 'Wow', '2023-11-29', 8, 'Munir'),
('u9.jpg', 'hahahaha', '2023-12-01', 9, 'Surya'),
('th.jpg', 'Keren Abizz', '2023-11-29', 45, 'Jhon');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `alam`
--
ALTER TABLE `alam`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `budaya`
--
ALTER TABLE `budaya`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `even`
--
ALTER TABLE `even`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `hiburan`
--
ALTER TABLE `hiburan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kuliner`
--
ALTER TABLE `kuliner`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `registrasi`
--
ALTER TABLE `registrasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `testimoni`
--
ALTER TABLE `testimoni`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `alam`
--
ALTER TABLE `alam`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `budaya`
--
ALTER TABLE `budaya`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `even`
--
ALTER TABLE `even`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `hiburan`
--
ALTER TABLE `hiburan`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `kuliner`
--
ALTER TABLE `kuliner`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `registrasi`
--
ALTER TABLE `registrasi`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `testimoni`
--
ALTER TABLE `testimoni`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
