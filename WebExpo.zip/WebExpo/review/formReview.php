<?php
include "../dashboard/fiturDash/koneksi.php";

	if(isset($_POST['aksi'])){

			$nama = $_POST['nama'];
			$foto = $_FILES['foto']['name'];
			$komentar = $_POST['komentar'];
			$tanggal = $_POST['tanggal'];

			$dir = "../img/";
			$tmpFile = $_FILES['foto']['tmp_name'];

			move_uploaded_file($tmpFile, $dir.$foto);

			$query_sql = "INSERT INTO testimoni (nama, foto, komentar, tanggal)
						VALUES ('$nama', '$foto', '$komentar', '$tanggal')";

			if (mysqli_query($conn, $query_sql)){
				header("Location: review.php");
			} else{
				echo "Pendaftaran Gagal: " . mysqli_error($conn);
			}
	}
?>

