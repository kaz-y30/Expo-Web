<?php
include "../dashboard/fiturDash/koneksi.php";
?>


<!DOCTYPE html>
<html lang="en" id="home">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Landing Page Djogja Nusantara</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,400;0,600;1,100&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="review.css">
</head>

<body>
    <header>
        <!-- <video autoplay muted loop>
            <source src=../img/video-indonesia.mp4">
        </video> -->
        <div class="navbar">
            <div class="container">
                <div class="box-navbar">
                    <div class="logo">                   
                        <h2><img src="../img/logo.png" style="width: 70px" alt="">Djogja Nusantara</h2>
                    </div>
                    <ul class="menu">
                        <li><a href="../landingPage/landingPage.php">Home</a></li>
                        <li><a href="../destinasi/dest.php">Destination</a></li>
                        <li><a href="../review/review.php">Testimoni</a></li>
                        <li class="active"><a href="../loginAndRegis/regis/regis.php">Login</a></li>
                    </ul>
                    <i class="fa-solid fa-bars menu-bar"></i>
                </div>
            </div>
        </div>

        <div class="judul">
            <div class="container">
                <div class="box-judul">
                    <div class="box">
                        <h1> Review <br/> Djogja Nusantara </h1>
                        <p>
                            Bagikan pengalaman tak terlupakan Anda dengan Djogja Noesantara! Dengarkan cerita penuh inspirasi dari para pelancong, temukan tips lokal yang berharga, dan sampaikan pengalaman anda. Berkontribusi untuk membantu wisatawan lain membuat pilihan yang tepat.
                        </p>
                    </div>
                    <div class="box">
                        <img src="../img/header.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="review">
        
            <div class="box-container">
            <?php
                $result = mysqli_query($conn, "SELECT * FROM testimoni");
                while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
                {
                ?>
                <div class="box">          
                    <img src="../img/<?php echo $row['foto'];?>" alt="">
                    <h3><?php echo $row['nama'];?></h3>
                    <p><?php echo $row['komentar'];?></p>
                    <p style="text-align: right"></p><?php echo $row['tanggal'];?></p>
                </div>
            <?php
            }
            ?> 
            </div>
    </div>
        
    <!-- End Main -->

    <!-- Komentar -->
    <div class="container">

                <h1 class="h3 mb-2 text-gray-800">Add Coment</h1>
                    <form action="formReview.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group row">   
                            <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                            <div class="col-sm-10">
                                <input required type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan nama">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
                            <div class="col-sm-10">
                                <input required type="date" class="form-control" id="tanggal" name="tanggal" placeholder="Masukkan Tanggal">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="foto" class = "col-sm-2 form-label">Input Foto</label>
                            <div class="col-sm-10">
                                <input type="file" class="form-control-file" id="foto" name="foto" accept="image/*" placeholder="Masukkan foto"> 
                            </div>            
                        </div>

                        <div class="form-group row">
                            <label for="komentar" class="col-sm-2 col-form-label">Komentar</label>
                            <div class="col-sm-10">
                                <textarea required type="text" class="form-control" id="komentar" name="komentar" placeholder="Masukkan komentar" cols="30" rows="10"></textarea>
                            </div>
                           
                        </div>
                        
                        <div class="mb-3 row">
                            <div class="col">
                                <button type="submit"  name="aksi" value="add" class="btn btn-info">
                                    <i class = "fa fa-floppy-o" aria-hidden = "true"></i> 
                                    Post Komen 
                                </button>
                            </div>                         
                        </div>
                    </form>
    </div>

    <div class="footer">
        <div class="cobtainer">
            <div class="box-footer">
                <div class="box">
                    <h2>Djogja Nusantara</h2>
                    <p>Pintu ke Keajaiban Yogyakarta. Jelajahi dengan penuh keceriaan, temukan pesona tak terduga, dan buatlah setiap langkah Anda menjadi kisah petualangan yang abadi.</p>
                </div>
                <div class="box">
                    <h3>Menu</h3>
                    <a href="#home">
                        Home
                    </a>
                    
                    <a href="#services">
                        Destination
                    </a>
                    
                    <a href="#Destinasi">
                        Testimoni
                    </a>
                    
                    <a href="#registrasi">
                        Registrasi
                    </a>
                </div>

                <div class="box">
                    <p>&copy; Copyright by Djogja Nusantara</p>
                </div>
            </div>
        </div>
    </div>

    <script src="review1.js"></script>
</body>
</html>

<?php mysqli_close($conn); ?>