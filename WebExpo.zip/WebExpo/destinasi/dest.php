<?php
include "../dashboard/fiturDash/koneksi.php";
?>


<!DOCTYPE html>
<html lang="en" id="home">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Landing Page Djogja Nusantara</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,400;0,600;1,100&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="dest.css">
</head>

<body>
    <header>
        <!-- <video autoplay muted loop>
            <source src=../img/video-indonesia.mp4">
        </video> -->
        <div class="navbar">
            <div class="container">
                <div class="box-navbar">
                    <div class="logo">
                        <h2><img src="../img/logo.png" style="width: 70px" alt="">Djogja Nusantara</h2>
                    </div>
                    <ul class="menu">
                        <li><a href="../landingPage/landingPage.php">Home</a></li>
                        <li><a href="../destinasi/dest.php">Destination</a></li>
                        <li><a href="../review/review.php">Testimoni</a></li>
                        <li class="active"><a href="../loginAndRegis/regis/regis.php">Login</a></li>
                    </ul>
                    <i class="fa-solid fa-bars menu-bar"></i>
                </div>
            </div>
        </div>

        <div class="judul">
            <div class="container">
                <div class="box-judul">
                    
                    <div class="box">
                        <h1>Destinasi Daerah <br/> Istimewa Yogyakarta</h1>
                        <p>
                            Jelajahi keajaiban Yogyakarta dengan Djogja Noesantara! Dari kemegahan Candi Prambanan hingga keindahan alam Gunung Merapi, kami hadirkan panduan lengkap destinasi wisata. Temukan keunikan setiap tempat, nikmati kekayaan budaya, dan ciptakan kenangan tak terlupakan di setiap perjalanan Anda.
                        </p>
                    </div>

                    <div class="box">
                        <img src="../img/ilustrasitugu.jpeg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="destinasi">

        <!-- Alam -->
        <div class="container">
            <h2>Alam</h2>
            <div class="box-destinasi">
            <?php
            $result = mysqli_query($conn, "SELECT * FROM alam");
            while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
            {
            ?>
                            <div class="box">
                                <h4><?php echo $row['judul'];?></h4>
                                <img src="../img/<?php echo $row['gambar'];?>"  alt="">
                                <h6><?php echo $row['tanggal'];?></h6>
                                <p><?php echo $row['informasi'];?></p>          
                             </div>
            <?php
            }
            ?>
            </div>
        </div>

        <!-- Budaya -->
        <div class="container">
            <h2>Budaya</h2>
            <div class="box-destinasi">

            <?php
            $result = mysqli_query($conn, "SELECT * FROM budaya");
            while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
            {
            ?>
                                <div class="box">
                                    <h2><?php echo $row['judul'];?></h2>
                                    <img src="../img/<?php echo $row['gambar'];?>"  alt="">
                                    <h5><?php echo $row['tanggal'];?></h5>
                                    <p><?php echo $row['informasi'];?></p>
                                </div>
            <?php
            }
            ?>

            </div>
        </div>

        <!-- Hiburan -->
        <div class="container">
            <h2>Hiburan</h2>
            <div class="box-destinasi">
            <?php
            $result = mysqli_query($conn, "SELECT * FROM hiburan");
            while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
            {
            ?>
                                <div class="box">
                                    <h2><?php echo $row['judul'];?></h2>                                  
                                    <img src="../img/<?php echo $row['gambar'];?>"  alt="">
                                    <h5><?php echo $row['tanggal'];?></h5>
                                    <p><?php echo $row['informasi'];?></p>           
                                </div>
            <?php
            }
            ?>
            </div>
            
    </div>

   
    <div class="footer">
        <div class="cobtainer">
            <div class="box-footer">
                <div class="box">
                    <h2>Djogja Nusantara</h2>
                    <p>Pintu ke Keajaiban Yogyakarta. Jelajahi dengan penuh keceriaan, temukan pesona tak terduga, dan buatlah setiap langkah Anda menjadi kisah petualangan yang abadi.</p>
                </div>
                <div class="box">
                    <h3>Menu</h3>
                    <a href="#home">
                        Home
                    </a>
                    
                    <a href="#services">
                        Destination
                    </a>
                    
                    <a href="#Destinasi">
                        Testimoni
                    </a>
                    
                    <a href="#registrasi">
                        Registrasi
                    </a>
                </div>

                <div class="box">
                    <p>&copy; Copyright by Djogja Nusantara</p>
                </div>
            </div>
        </div>
    </div>

    <script src="../review/review1.js"></script>
</body>
</html>

<?php mysqli_close($conn); ?>