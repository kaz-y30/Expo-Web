<?php
include "../dashboard/fiturDash/koneksi.php";
?>


<!DOCTYPE html>
<html lang="en" id="home">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Landing Page Djogja Nusantara</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,400;0,600;1,100&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="landingPage.css">
</head>

<body>
    <header>
        <!-- <video autoplay muted loop>
            <source src=../img/video-indonesia.mp4">
        </video> -->
        <div class="navbar">
            <div class="container">
                <div class="box-navbar">
                    <div class="logo">
                        <h2><img src="../img/logo.png" style="width: 70px" alt="">Djogja Nusantara</h2>
                    </div>
                        <ul class="menu">
                            <li><a href="../landingPage/landingPage.php">Home</a></li>
                            <li><a href="../destinasi/dest.php">Destination</a></li>
                            <li><a href="../review/review.php">Testimoni</a></li>
                            <li class="active"><a href="../loginAndRegis/regis/regis.php">Login</a></li>
                        </ul>
                        <i class="fa-solid fa-bars menu-bar"></i>
                </div>
            </div>
        </div>

        <div class="judul">
            <div class="container">
                <div class="box-judul">
                    <div class="box">
                        <h1>Djogja Nusantara</h1>
                        <p>
                            Selamat datang di Djogja Noesantara, panduan wisata terbaik untuk menjelajahi pesona Yogyakarta. Temukan keindahan budaya, alam, Hiburan, kuliner,event & festival dengan mudah, karena setiap sudut Yogyakarta memiliki cerita yang menakjubkan. Mulailah petualangan Anda di sini!
                        </p>
                    </div>
                    <div class="box">
                        <img src="../img/1.jpg" alt="" style="height: 300px">
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="teamwork">
        <h1>Anggota Tim</h1>
        <div class="team-container">

            <div class="team">
                <img src="../img/ellipse-4-bg.png" alt="">
                <h3>Daffa Al Fajri</h3>
                <p>22523277</p>
                <div class="icons">
                    <a href="" class="fab fa-facebook"></a>
                    <a href="" class="fab fa-twitter"></a>
                    <a href="https://www.instagram.com/daffa.alkarim/" class="fab fa-instagram"></a>
                    <a href="" class="fab fa-github"></a>
                </div>
            </div>

            <div class="team">
                <img src="../img/ellipse-1-bg.png" alt="">
                <h3>Kasyiful Kurobi Alqorrosyai'</h3>
                <p>22523178</p>
                <div class="icons">
                    <a href="" class="fab fa-facebook"></a>
                    <a href="" class="fab fa-twitter"></a>
                    <a href="" class="fab fa-instagram"></a>
                    <a href="" class="fab fa-github"></a>
                </div>
            </div>

            <div class="team">
                <img src="../img/ellipse-2-bg.png" alt="">
                <h3>Mozanda Tiara Dewanti</h3>
                <p>22523243</p>
                <div class="icons">
                    <a href="" class="fab fa-facebook"></a>
                    <a href="" class="fab fa-twitter"></a>
                    <a href="https://instagram.com/mozanda?igshid=NzZlODBkYWE4Ng%3D%3D&utm_source=qr" class="fab fa-instagram"></a>
                    <a href="" class="fab fa-github"></a>
                </div>
            </div>

            <div class="team">
                <img src="../img/ellipse-5-bg.png" alt="">
                <h3>Muhammad Haekal Raka Sampoerna</h3>
                <p>22523129</p>
                <div class="icons">
                    <a href="" class="fab fa-facebook"></a>
                    <a href="" class="fab fa-twitter"></a>
                    <a href="https://www.instagram.com/kakarizaa/" class="fab fa-instagram"></a>
                    <a href="" class="fab fa-github"></a>
                </div>
            </div>

            <div class="team">
                <img src="../img/ellipse-3-bg.png" alt="">
                <h3>Safinatun Najah</h3>
                <p>22523205</p>
                <div class="icons">
                    <a href="" class="fab fa-facebook"></a>
                    <a href="" class="fab fa-twitter"></a>
                    <a href="" class="fab fa-instagram"></a>
                    <a href="" class="fab fa-github"></a>
                </div>
            </div>

        </div>
    </div>

    <!-- Main -->
    <section class="main">
        <div class="review">
            <h2>Event & Festival</h2>  
        </div>

        <div class="content">
            <?php
            $result = mysqli_query($conn, "SELECT * FROM even");
            while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
            {
            ?>
            <div class="row">
                <img src="../img/<?php echo $row['gambar'];?>" alt="">
                <div class="layer">
                    <h5><?php echo $row['nama'];?></h5>
                    <p><?php echo $row['deskripsi'];?></p>
                </div>
            </div> 
            <?php
            }
            ?>         
        </div>

        <div class="review">
            <h2>Kuliner</h2>  
        </div>

        <div class="content">
            <?php
            $result = mysqli_query($conn, "SELECT * FROM kuliner");
            while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
            {
            ?>
            <div class="row">
                <img src="../img/<?php echo $row['gambar'];?>" alt="">
                <div class="layer">
                    <h5><?php echo $row['nama_kuliner'];?></h5>
                    <p><?php echo $row['isi'];?></p>
                </div>
            </div> 
            <?php
            }
            ?>         
        </div>
    </section>

    <div class="footer">
        <div class="cobtainer">
            <div class="box-footer">
                <div class="box">
                    <h2>Djogja Nusantara</h2>
                    <p>Pintu ke Keajaiban Yogyakarta. Jelajahi dengan penuh keceriaan, temukan pesona tak terduga, dan buatlah setiap langkah Anda menjadi kisah petualangan yang abadi.</p>
                </div>
                <div class="box">
                    <h3>Menu</h3>
                    <a href="#home">
                        Home
                    </a>
                    
                    <a href="#services">
                        Destination
                    </a>
                    
                    <a href="#Destinasi">
                        Testimoni
                    </a>
                    
                    <a href="#registrasi">
                        Registrasi
                    </a>
                </div>

                <div class="box">
                    <p>&copy; Copyright by Djogja Nusantara</p>
                </div>
            </div>
        </div>
    </div>

    <script src="../review/review1.js"></script>
</body>
</html>

<?php mysqli_close($conn); ?>












    <!-- <div class="regis" id="regis">
        <div class="container">
            <div class="box-regis">
                <h1>
                    Ingin Berlibur Bersama Keluarga Maupun Teman? <br/>
                    Segera Daftar!
                </h1>
                <h3>Klik Link Dibawah Ini</h3>
                <button>
                    <i class="fa-brands fa-whatsapp"></i>
                    Whatsapp
                </button>

                <button>
                    <i class="fa-regular fa-envelope"></i>
                    Gmail
                </button>

                <button>
                    <i class="fa-regular fa-clipboard"></i>
                    Google Form
                </button>

            </div>
        </div>
    </div> -->
