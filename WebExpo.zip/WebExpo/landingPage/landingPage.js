const menuBar = document.querySelector(".menu-bar")
const menunav = document.querySelector(".menu");

menuBar.addEventListener("click", () =>{
    menunav.classList.toggle(menu-active);
});

const navBar = document.querySelector(".navbar");

window.addEventListener("scroll", () =>{
    console.log(window.scrollY);
    const windowPosition = window.scrolY > 0;
    navBar.classList.toogle("scrolling-active", windowPosition);
    menunav.classList.remove("menu-active");
});