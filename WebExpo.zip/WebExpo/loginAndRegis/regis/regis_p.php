<?php
include "../../dashboard/fiturDash/koneksi.php";

$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$password = md5($password);

$query_sql = "INSERT INTO registrasi (username, email, password)
			  VALUES ('$username', '$email', '$password')";

if (mysqli_query($conn, $query_sql)){
	header("Location: ../../loginAndRegis/login/login.php");
} else{
	echo "Pendaftaran Gagal: " . mysqli_error($conn);
}

?>
