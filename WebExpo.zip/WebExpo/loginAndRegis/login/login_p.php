<?php
include "../../dashboard/fiturDash/koneksi.php";

$email = $_POST['email'];
$password = $_POST['password'];
$password = md5($password);

$query_sql =  "SELECT * FROM registrasi WHERE email = '$email' AND password = '$password'";
$result = mysqli_query($conn, $query_sql);


if (mysqli_num_rows($result) > 0) {
	$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
	if ($row['email'] == "admin@hotmail.com"){
		header ("Location: ../../dashboard/fiturDash/dashboard.php");
	}else {
		header("Location: ../../landingPage/landingPage.php");
	}
	
} else{
	echo "Tidak ada data" ;
}
?>

















<!-- // $prevQuery = mysqli_query($conn, "SELECT * FROM login WHERE username = '$username'");
// $data = mysqli_fetch_array($prevQuery, MYSQLI_ASSOC);

// if ($password == $data['password'])
// {
//     $_SESSION['dede'] = $data['id'];
//     echo '<META HTTP-EQUIV="Refresh" Content="0; URL=admin.php">';
// 	exit;
// }
// else
// echo "<script>
// 	alert ('Login Gagal');
// 	</script>";
// 	    echo '<META HTTP-EQUIV="Refresh" Content="0; URL=login.php">'; -->


