<?php
include "../../dashboard/fiturDash/koneksi.php";

	if(isset($_POST['aksi'])){

		if($_POST['aksi'] == "add"){

			$username = $_POST['username'];
			$email = $_POST['email'];
			$password = $_POST['password'];
            $password = md5($password);


			$query_sql = "INSERT INTO registrasi (username, email, password)
						  VALUES ('$username', '$email', '$password')";

			if (mysqli_query($conn, $query_sql)){
				header("Location: ../../dashboard/fiturDash/dashUser.php");
			} else{
				echo "Pendaftaran Gagal: " . mysqli_error($conn);
			}
			// echo "Berhasil <a href='../../dashboard/fiturDash/dashDestinasi.php'>HOME</a>";
		} else if($_POST['aksi'] == "edit"){

			$username = $_POST['username'];
			$email = $_POST['email'];
			$password = $_POST['password'];
            $password = md5($password);

			$row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

			$query = "UPDATE registrasi SET username='$username', email='$email', password='$password' WHERE id='$id';";

			$sql = mysqli_query($conn, $query);

			header("Location: ../../dashboard/fiturDash/dashUser.php");
		}
		
	}

	if(isset($_GET['hapus'])){

		$id = $_GET['hapus'];
		$query = "DELETE FROM registrasi WHERE id=$id";

		if (mysqli_query($conn, $query)){
			header("Location: ../../dashboard/fiturDash/dashUser.php");
		} else{
			echo "Pendaftaran Gagal: " . mysqli_error($conn);
		}
		// echo "Hapus berhasil";
	}

?>
