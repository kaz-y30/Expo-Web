<?php
include "../../dashboard/fiturDash/koneksi.php";

	if(isset($_POST['aksi'])){

		if($_POST['aksi'] == "add"){

			$name = $_POST['nama_kuliner'];
			$gambar = $_FILES['gambar']['name'];
			$informasi = $_POST['isi'];
			$tanggal = $_POST['tanggal'];



			$dir = "../../img/";
			$tmpFile = $_FILES['gambar']['tmp_name'];

			move_uploaded_file($tmpFile, $dir.$gambar);

			$query_sql = "INSERT INTO kuliner (nama_kuliner, gambar, isi, tanggal)
						  VALUES ('$name', '$gambar', '$informasi', '$tanggal')";

			if (mysqli_query($conn, $query_sql)){
				header("Location: ../../dashboard/fiturDash/dashKuliner.php");
			} else{
				echo "Pendaftaran Gagal: " . mysqli_error($conn);
			}
			// echo "Berhasil <a href='../../dashboard/fiturDash/dashKuliner.php'>HOME</a>";
		} else if($_POST['aksi'] == "edit"){

			$id = $_POST['id'];
			$name = $_POST['nama_kuliner'];
			$informasi = $_POST['isi'];
			$tanggal = $_POST['tanggal'];

			$queryShow = "SELECT * FROM kuliner WHERE id='$id';";
			$sqlShow = mysqli_query($conn, $queryShow);
			$row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

			if($_FILES['gambar']['name'] == ""){
				$gambar = $row['gambar'];
			}else{
				$gambar = $_FILES['gambar']['name'];
			}

			$query = "UPDATE kuliner SET nama_kuliner='$name', isi='$informasi', 
					  gambar='$gambar', tanggal='$tanggal' WHERE id='$id';";
					  unlink("../../img/".$row['gambar']);
					  move_uploaded_file($_FILES['gambar']['tmp_name'], '../../img/'.$_FILES['gambar']['name']);

			$sql = mysqli_query($conn, $query);

			header("Location: ../../dashboard/fiturDash/dashKuliner.php");
		}
		
	}

	if(isset($_GET['hapus'])){
		$id = $_GET['hapus'];

		$queryShow = "SELECT * FROM kuliner WHERE id='$id';";
		$sqlShow = mysqli_query($conn, $queryShow);
		$row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

		unlink("../../img/".$row['gambar']);

		$query = "DELETE FROM kuliner WHERE id=$id";

		if (mysqli_query($conn, $query)){
			header("Location: ../../dashboard/fiturDash/dashKuliner.php");
		} else{
			echo "Pendaftaran Gagal: " . mysqli_error($conn);
		}
		// echo "Hapus berhasil";
	}

?>
