<?php
include "../../dashboard/fiturDash/koneksi.php";

	if(isset($_POST['aksi'])){

		if($_POST['aksi'] == "add"){

			$name = $_POST['nama'];
			$gambar = $_FILES['gambar']['name'];
			$deskripsi = $_POST['deskripsi'];

			$dir = "../../img/";
			$tmpFile = $_FILES['gambar']['tmp_name'];

			move_uploaded_file($tmpFile, $dir.$gambar);

			$query_sql = "INSERT INTO even (nama, gambar, deskripsi)
						  VALUES ('$name', '$gambar', '$deskripsi')";

			if (mysqli_query($conn, $query_sql)){
				header("Location: ../../dashboard/fiturDash/dashEven.php");
			} else{
				echo "Pendaftaran Gagal: " . mysqli_error($conn);
			}
			// echo "Berhasil <a href='../../dashboard/fiturDash/dashDestinasi.php'>HOME</a>";
		} else if($_POST['aksi'] == "edit"){

			$id = $_POST['id'];
			$name = $_POST['nama'];
			$deskripsi = $_POST['deskripsi'];

			$queryShow = "SELECT * FROM even WHERE id='$id';";
			$sqlShow = mysqli_query($conn, $queryShow);
			$row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

			if($_FILES['gambar']['name'] == ""){
				$gambar = $row['gambar'];
			}else{
				$gambar = $_FILES['gambar']['name'];
			}

			$query = "UPDATE even SET nama='$name', deskripsi='$deskripsi', 
					  gambar='$gambar' WHERE id='$id';";
					  unlink("../../img/".$row['gambar']);
					  move_uploaded_file($_FILES['gambar']['tmp_name'], '../../img/'.$_FILES['gambar']['name']);

			$sql = mysqli_query($conn, $query);

			header("Location: ../../dashboard/fiturDash/dashEven.php");
		}
		
	}

	if(isset($_GET['hapus'])){
		$id = $_GET['hapus'];

		$queryShow = "SELECT * FROM even WHERE id='$id';";
		$sqlShow = mysqli_query($conn, $queryShow);
		$row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

		unlink("../../img/".$row['gambar']);

		$query = "DELETE FROM even WHERE id=$id";

		if (mysqli_query($conn, $query)){
			header("Location: ../../dashboard/fiturDash/dashEven.php");
		} else{
			echo "Pendaftaran Gagal: " . mysqli_error($conn);
		}
		// echo "Hapus berhasil";
	}

?>
