<?php
include "../../dashboard/fiturDash/koneksi.php";

	if(isset($_POST['aksi'])){

		if($_POST['aksi'] == "add"){

			$judul = $_POST['judul'];
			$gambar = $_FILES['gambar']['name'];
			$informasi = $_POST['informasi'];
			$tanggal = $_POST['tanggal'];

			$dir = "../../img/";
			$tmpFile = $_FILES['gambar']['tmp_name'];

			move_uploaded_file($tmpFile, $dir.$gambar);

			$query_sql = "INSERT INTO budaya (judul, gambar, informasi, tanggal)
						  VALUES ('$judul', '$gambar', '$informasi', '$tanggal')";

			if (mysqli_query($conn, $query_sql)){
				header("Location: ../../dashboard/fiturDash/dashDestinasi.php");
			} else{
				echo "Pendaftaran Gagal: " . mysqli_error($conn);
			}
			// echo "Berhasil <a href='../../dashboard/fiturDash/dashDestinasi.php'>HOME</a>";
		} else if($_POST['aksi'] == "edit"){

			$id = $_POST['id'];
			$judul = $_POST['judul'];
			$informasi = $_POST['informasi'];
			$tanggal = $_POST['tanggal'];

			$queryShow = "SELECT * FROM budaya WHERE id='$id';";
			$sqlShow = mysqli_query($conn, $queryShow);
			$row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

			if($_FILES['gambar']['name'] == ""){
				$gambar = $row['gambar'];
			}else{
				$gambar = $_FILES['gambar']['name'];
			}

			$query = "UPDATE budaya SET judul='$judul', informasi='$informasi', tanggal='$tanggal', 
					  gambar='$gambar' WHERE id='$id';";
					  unlink("../../img/".$row['gambar']);
					  move_uploaded_file($_FILES['gambar']['tmp_name'], '../../img/'.$_FILES['gambar']['name']);

			$sql = mysqli_query($conn, $query);

			header("Location: ../../dashboard/fiturDash/dashDestinasi.php");
		}
		
	}

	if(isset($_GET['delete'])){
		$id = $_GET['delete'];

		$queryShow = "SELECT * FROM budaya WHERE id='$id';";
		$sqlShow = mysqli_query($conn, $queryShow);
		$row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

		unlink("../../img/".$row['gambar']);

		$query = "DELETE FROM budaya WHERE id=$id";

		if (mysqli_query($conn, $query)){
			header("Location: ../../dashboard/fiturDash/dashDestinasi.php");
		} else{
			echo "Pendaftaran Gagal: " . mysqli_error($conn);
		}
		// echo "Hapus berhasil";
	}

?>
