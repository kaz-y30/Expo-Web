<?php
include "../../dashboard/fiturDash/koneksi.php";

	if(isset($_POST['aksi'])){

		if($_POST['aksi'] == "add"){

			$nama = $_POST['nama'];
			$foto = $_FILES['foto']['name'];
			$komentar = $_POST['komentar'];
			$tanggal = $_POST['tanggal'];

			$dir = "../../img/";
			$tmpFile = $_FILES['foto']['tmp_name'];

			move_uploaded_file($tmpFile, $dir.$foto);

			$query_sql = "INSERT INTO testimoni (nama, foto, komentar, tanggal)
						  VALUES ('$nama', '$foto', '$komentar', '$tanggal')";

			if (mysqli_query($conn, $query_sql)){
				header("Location: ../../dashboard/fiturDash/dashTestimoni.php");
			} else{
				echo "Pendaftaran Gagal: " . mysqli_error($conn);
			}
			// echo "Berhasil <a href='../../dashboard/fiturDash/dashTestimoni.php'>HOME</a>";
		} else if($_POST['aksi'] == "edit"){

			$id = $_POST['id'];
			$nama = $_POST['nama'];
			$komentar = $_POST['komentar'];
			$tanggal = $_POST['tanggal'];

			$queryShow = "SELECT * FROM testimoni WHERE id='$id';";
			$sqlShow = mysqli_query($conn, $queryShow);
			$row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

			if($_FILES['foto']['name'] == ""){
				$foto = $row['foto'];
			}else{
				$foto = $_FILES['foto']['name'];
			}

			$query = "UPDATE testimoni SET nama='$nama', komentar='$komentar', tanggal='$tanggal', 
					  foto='$foto' WHERE id='$id';";
					  unlink("../../img/".$row['foto']);
					  move_uploaded_file($_FILES['foto']['tmp_name'], '../../img/'.$_FILES['foto']['name']);

			$sql = mysqli_query($conn, $query);

			header("Location: ../../dashboard/fiturDash/dashTestimoni.php");
		}
		
	}

	if(isset($_GET['hapus'])){
		$id = $_GET['hapus'];

		$queryShow = "SELECT * FROM testimoni WHERE id='$id';";
		$sqlShow = mysqli_query($conn, $queryShow);
		$row = mysqli_fetch_array($sqlShow, MYSQLI_ASSOC);

		unlink("../../img/".$row['foto']);

		$query = "DELETE FROM testimoni WHERE id=$id";

		if (mysqli_query($conn, $query)){
			header("Location: ../../dashboard/fiturDash/dashTestimoni.php");
		} else{
			echo "Pendaftaran Gagal: " . mysqli_error($conn);
		}
		// echo "Hapus berhasil";
	}

?>
